Thanks for Downloading!
Your data is in export.json and the images are in the folder!